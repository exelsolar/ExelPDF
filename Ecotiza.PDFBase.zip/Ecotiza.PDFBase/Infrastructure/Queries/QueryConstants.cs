﻿namespace Ecotiza.PDFBase.Infrastructure.Queries
{
    public static class QueryConstants
    {
        public static readonly string OrderByAscending = "ASC";
        public static readonly string OrderByDescending = "DESC";
    }
}