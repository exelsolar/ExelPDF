﻿namespace Ecotiza.PDFBase.Infrastructure.Enums
{
    public class Enumerator
    {
        public int Value { get; set; }
        public string Name { get; set; }
    }
}