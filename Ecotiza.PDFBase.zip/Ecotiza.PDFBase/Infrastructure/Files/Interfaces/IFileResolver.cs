﻿namespace Ecotiza.PDFBase.Infrastructure.Files.Interfaces
{
    public interface IFileResolver
    {
        string Resolve(string filePath);
    }
}