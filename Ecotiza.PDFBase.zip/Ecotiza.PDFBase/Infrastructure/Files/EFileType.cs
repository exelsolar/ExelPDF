﻿namespace Ecotiza.PDFBase.Infrastructure.Files
{
    public enum EFileType
    {
        Pdf = 1,
        Image = 2
    }
}