﻿namespace Ecotiza.PDFBase.Infrastructure.Infrastructure
{
    public interface IPasswordGenerator
    {
        string Generate();
    }
}