﻿namespace Ecotiza.PDFBase.Infrastructure.Validators
{
    public enum ECodeValidator
    {
        InternalServer = 1,
        NotFound = 2,
        DataAccess = 3
    }
}