﻿namespace Ecotiza.PDFBase.Infrastructure.Constants
{
    public class MigrationConstants
    {
        public const int SystemUserId = 1;
        public const string SystemFirstName = "Admin";
        public const string SystemFatherLastName = "Admin";
        public const string SystemMotherLastName = "Admin";
        public const string SystemEmail = "superusuario.insejupy@gmail.com";
        public const string SystemPassword = "admin";
      
        public const int StatusActivatedMigration = 1;
    }
}