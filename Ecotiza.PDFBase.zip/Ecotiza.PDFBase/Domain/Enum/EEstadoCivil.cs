﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecotiza.PDFBase.Domain.Enum
{
    public enum EEstadoCivil
    {
        Soltero=1,
        Casado=2
    }
}
