﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecotiza.PDFBase.Domain.Enum
{
    public enum EProducto
    {
        Infonavit=1,
        Confinavit=2,
        InfornavitTotal=3,
        ConfinavitIngresosAdicionales=4,
        EntidadFinanciera=5
    }
}
