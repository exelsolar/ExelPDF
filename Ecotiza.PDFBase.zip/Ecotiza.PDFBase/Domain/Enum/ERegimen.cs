﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecotiza.PDFBase.Domain.Enum
{
    public enum ERegimen
    {
        SeparadoBienes=1,
        SociedadConyugal = 2,
        SociedadLegal = 3
    }
}
