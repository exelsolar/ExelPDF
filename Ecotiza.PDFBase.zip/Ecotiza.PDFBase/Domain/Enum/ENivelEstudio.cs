﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecotiza.PDFBase.Domain.Enum
{
    public enum ENivelEstudio
    {
        SinEstudio=1,
        Primaria = 2,
        Secundaria = 3,
        Preparatoria = 4,
        Tecnico = 5,
        Licenciatura = 6,
        Posgrado = 7
    }
}
